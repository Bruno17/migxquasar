import getters from './getters';
import setters from './setters';

const vfjsModel = {
  ...getters,
  ...setters,
};

export default vfjsModel;
