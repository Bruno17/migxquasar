# attrs

Essentially any normal html attributes

```js
// Normal HTML attributes
data() {
  return {
    uiSchema: [{
      component: 'div',
      fieldOptions: {
        attrs: {
          id: 'foo',
          placeholder: 'bar'
        }
      }
    }]
  }
}
```
