import getters from './getters';
import setters from './setters';

const vfjsUi = {
  ...getters,
  ...setters,
};

export default vfjsUi;
