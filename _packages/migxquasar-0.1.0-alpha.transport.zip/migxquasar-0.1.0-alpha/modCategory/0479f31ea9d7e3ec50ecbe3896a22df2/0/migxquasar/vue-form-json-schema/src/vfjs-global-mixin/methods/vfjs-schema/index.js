import getters from './getters';
import setters from './setters';

const vfjsSchema = {
  ...getters,
  ...setters,
};

export default vfjsSchema;
