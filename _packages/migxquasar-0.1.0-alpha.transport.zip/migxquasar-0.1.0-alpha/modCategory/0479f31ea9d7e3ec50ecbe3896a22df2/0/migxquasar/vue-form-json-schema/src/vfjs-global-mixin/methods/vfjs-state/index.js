import getters from './getters';
import setters from './setters';

const vfjsState = {
  ...getters,
  ...setters,
};

export default vfjsState;
