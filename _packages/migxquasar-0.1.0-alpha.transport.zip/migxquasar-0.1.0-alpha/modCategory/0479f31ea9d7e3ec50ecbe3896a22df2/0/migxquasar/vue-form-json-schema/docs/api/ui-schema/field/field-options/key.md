# key

> The key special attribute is primarily used as a hint for Vue’s virtual DOM algorithm to identify VNodes when diffing the new list of nodes against the old list. - [Vue.js guide](https://vuejs.org/v2/api/#key)

This property is set to each field's unique internal id by default. You can optionally override it should you wish to specifiy it.
