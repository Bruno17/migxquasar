# schema

Any valid [JSON Schema](http://json-schema.org).

Good resources if you are new to JSON Schema is:

* [Understanding JSON schema](https://spacetelescope.github.io/understanding-json-schema/)
* [Online JSON schema validator](http://jsonschemavalidator.net)
* [Ajv documentation (internal JSON schema validation engine)](https://epoberezkin.github.io/ajv/)
* [Ajv github](https://github.com/epoberezkin/ajv)
