<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '371aa4bca721ae777fd47e456950b0b2',
      'native_key' => 'migxquasar',
      'filename' => 'modNamespace/ccba502cee968793c0895afc17e1ca82.vehicle',
      'namespace' => 'migxquasar',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '5f2d59a7d7abdfa45ad07f4c4b3a1106',
      'native_key' => NULL,
      'filename' => 'modCategory/0479f31ea9d7e3ec50ecbe3896a22df2.vehicle',
      'namespace' => 'migxquasar',
    ),
  ),
);