<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '9e6376837e3f5a2a99d4755b452189d0',
      'native_key' => 'migxquasar',
      'filename' => 'modNamespace/b5fe61a7366cd9d35ef2914bfb7c95c2.vehicle',
      'namespace' => 'migxquasar',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'fee06841e6d336fa2b2a4006eb41e651',
      'native_key' => NULL,
      'filename' => 'modCategory/41e9386b3d4fe915bc24bbc0b0ebe454.vehicle',
      'namespace' => 'migxquasar',
    ),
  ),
);